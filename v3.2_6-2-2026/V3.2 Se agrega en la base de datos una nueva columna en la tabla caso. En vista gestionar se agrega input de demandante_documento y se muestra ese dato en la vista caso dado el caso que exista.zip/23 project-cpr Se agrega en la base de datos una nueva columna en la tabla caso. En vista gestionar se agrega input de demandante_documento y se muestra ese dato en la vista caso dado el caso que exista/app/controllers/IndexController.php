<?php

class IndexController
{
    public function index()
    {
        require '../app/views/public/index.php';
    }
}
