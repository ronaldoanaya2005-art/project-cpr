<link rel="stylesheet" href="/PROJECT-CPR/public/assets/css/globals/header.css"/>


<div class="header-background">
  <header class="header"> <!-- Logo a la izquierda -->
    <div class="logo"> <a href="index.php"> <img src="assets/img/logo-sena-cpr.png" alt="Logo SENA CPR"> </a> </div> <!-- Botones a la derecha -->
    <nav class="nav-menu"> <a href="login.php" class="nav-item <?php echo ($activePage === 'login') ? 'active' : ''; ?>">Ingresar</a> </nav>
  </header>
</div>

