<link rel="stylesheet" href="/PROJECT-CPR/public/assets/css/globals/footer.css">

<footer class="footer">
    <div class="footer-column">
        <h4>Enlaces útiles:</h4>
        <ul>
            <li>Manual de Usuario</li>
            <li>Soporte</li>
            <li>Política de Privacidad</li>
        </ul>
    </div>

    <div class="footer-column">
        <p>Dirección: Calle XX # XX-XX, Bogotá, Colombia<br>
            Conmutador: (601) 5461500<br>
            comisionpersonal@sena.edu.co</p>
    </div>

    <div class="footer-column">
        <p>© 2026 SENA – Comisión de Personal<br>
            Todos los derechos reservados</p>
    </div>
</footer>