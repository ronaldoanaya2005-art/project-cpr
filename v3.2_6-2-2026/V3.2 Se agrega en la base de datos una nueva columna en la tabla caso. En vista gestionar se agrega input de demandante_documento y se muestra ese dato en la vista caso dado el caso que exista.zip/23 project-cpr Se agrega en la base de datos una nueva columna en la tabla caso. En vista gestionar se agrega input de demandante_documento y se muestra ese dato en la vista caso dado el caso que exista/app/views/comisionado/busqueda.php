<?php $activePage = 'busqueda';

session_start();

if (!isset($_SESSION['logged']) || $_SESSION['user']['rol'] != 2) {
    header("Location: /project-cpr/public/login.php");
    exit;
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Búsqueda - CPR</title>
    <link rel="stylesheet" href="/project-cpr/public/assets/css/globals/base.css">
    <link rel="stylesheet" href="/project-cpr/public/assets/css/globals/busqueda_caso.css">
</head>

<body class="private">

    <?php include('../components/header_comisionado.php'); ?>

    <div class="main-content">
        <!-- Todo tu contenido de busqueda.php -->
        <?php include __DIR__ . '/../components/busqueda_caso.php'; ?>


    </div>

</body>

</html>